#!/bin/bash
echo what is your name?
read name

echo Hi $name welcome to goa





