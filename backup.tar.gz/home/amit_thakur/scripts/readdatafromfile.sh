#!/bin/bash

names="/home/amit_thakur/scripts/name"

for name in $(cat $names)
do
	echo characters of hera pheri is $name
done
