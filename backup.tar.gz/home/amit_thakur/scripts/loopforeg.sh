#!/bin/bash
for i in 1 2 3
do
	echo Number is $i
done


for num in {1..10}
do
	echo Number is $num
done

for task in Read Write Eat Sleep Play Diet Fight
do
	echo My task is $task
done
