#!/bin/bash

name=prashant
age=27
echo My name is $name
echo my age is $age
