#!/bin/bash

echo "No of argument are $#"
echo
echo $@
echo
echo "First argument is $1"
echo
echo "Second argument is $2"
echo
